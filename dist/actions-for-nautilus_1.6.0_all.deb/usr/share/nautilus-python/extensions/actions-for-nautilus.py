import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'actions-for-nautilus'))
from actions_for_nautilus import ActionsForNautilus
